--[[
    ADD YOUR FRAMEWORK BILLING HERE

    If the player is bill successfully, return true. If they're not, return false
]]
function BillPlayer(source, amount)
    return true
end