ESX             = nil

local injuryBasePrice = 8500

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

local beds = {
    { x = 307.72, y = -581.75, z = 44.34, h = 158.25, taken = false, model = 1631638868 },
    { x = 309.35, y = -577.38, z = 44.34, h = 340.68, taken = false, model = 1631638868 },
}

local bedsTaken = {}

AddEventHandler('playerDropped', function()
    if bedsTaken[source] ~= nil then
        beds[bedsTaken[source]].taken = false
    end
end)

RegisterServerEvent('mythic_hospital:server:RequestBed')
AddEventHandler('mythic_hospital:server:RequestBed', function()
    for k, v in pairs(beds) do
        if not v.taken then
            v.taken = true
            bedsTaken[source] = k
            TriggerClientEvent('mythic_hospital:client:SendToBed', source, k, v)
            return
        end
    end

    TriggerClientEvent('mythic_notify:client:SendAlert', source, { type = 'error', text = 'No Beds Available' })
end)

RegisterServerEvent('mythic_hospital:server:RPRequestBed')
AddEventHandler('mythic_hospital:server:RPRequestBed', function(plyCoords)
    local foundbed = false
    for k, v in pairs(beds) do
        local distance = #(vector3(v.x, v.y, v.z) - plyCoords)
        if distance < 3.0 then
            if not v.taken then
                v.taken = true
                foundbed = true
                TriggerClientEvent('mythic_hospital:client:RPSendToBed', source, k, v)
                return
            else
                TriggerEvent('chatMessage', '', { 0, 0, 0 }, 'NThat Bed Is Taken')
            end
        end
    end

    if not foundbed then
        TriggerEvent('chatMessage', '', { 0, 0, 0 }, 'Not Near A Hospital Bed')
    end
end)

RegisterServerEvent('mythic_hospital:server:EnteredBed')
AddEventHandler('mythic_hospital:server:EnteredBed', function()
    local src = source
	local totalBill = injuryBasePrice
    local xPlayer = ESX.GetPlayerFromId(src)

    
    if BillPlayer(src) then
        TriggerClientEvent('mythic_notify:client:SendAlert', src, { text = 'You\'ve Been Treated & Billed $8,500 for medical service.', type = 'inform', style = { ['background-color'] = '#760036' }})
        TriggerClientEvent('mythic_hospital:client:FinishServices', src, false, true)
		xPlayer.removeBank(totalBill)
    else
        TriggerClientEvent('mythic_notify:client:SendAlert', src, { text = 'You were revived, but did not have the funds to cover further medical services', type = 'inform', style = { ['background-color'] = '#760036' }})
        TriggerClientEvent('mythic_hospital:client:FinishServices', src, false, false)
		xPlayer.removeBank(totalBill)
    end
	
	TriggerEvent('esx_addonaccount:getSharedAccount', 'society_ambulance', function(account)
	account.addMoney(totalBill)
	end)
end)

RegisterServerEvent('mythic_hospital:server:LeaveBed')
AddEventHandler('mythic_hospital:server:LeaveBed', function(id)
    beds[id].taken = false
end)