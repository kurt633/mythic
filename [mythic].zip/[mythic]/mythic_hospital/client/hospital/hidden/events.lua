RegisterNetEvent('mythic_hospital:client:HiddenSetup')
AddEventHandler('mythic_hospital:client:HiddenSetup', function()
    usedHiddenRev = false
end)