# PillboxHospital-doors
doors for the PillboxHospital by Jobscraft



# instal

if you have allready a map resource:

- put the content of the stream folder, in the stream folder of your map resource
- enjoy

if you don't have any map resource :

- put the script in your resource folder
- start the resource in your server.cfg
- enjoy
